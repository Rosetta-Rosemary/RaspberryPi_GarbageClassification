#include <GetIpAndMac.hpp>

/*
    初步完成日期 20210202
    适用于windows平台与Linux平台获取本地Ip与机器码
    Ip以 char* 形式返回
    bool GetLocalIp(std::string &ip)
*/